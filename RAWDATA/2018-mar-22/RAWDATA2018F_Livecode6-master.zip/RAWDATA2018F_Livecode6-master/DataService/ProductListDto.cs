﻿namespace DataService
{
    public class ProductListDto
    {
        public string Name { get; set; }

        public double UnitPrice { get; set; }

        public string CategoryName { get; set; }
    }
}
