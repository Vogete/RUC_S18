﻿namespace DataService
{
    public class ProductCategoryNameListDto
    {
        public string ProductName { get; set; }
        public string CategoryName { get; set; }
    }
}
